package ast;

public abstract class Expression extends AST {

}
