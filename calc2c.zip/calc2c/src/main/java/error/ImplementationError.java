package error;

public class ImplementationError extends RuntimeException {

}
