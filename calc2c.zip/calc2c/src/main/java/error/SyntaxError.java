package error;

public class SyntaxError extends RuntimeException {

}
