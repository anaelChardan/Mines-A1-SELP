#include <stdio.h>
#include <stdbool.h>

int main () { 
    return printf("%i", ! false&&true); 
 }