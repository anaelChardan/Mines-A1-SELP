#include <stdio.h>
#include <stdbool.h>

int main () { 
    return printf("%i", 21>12 ? 12==21 ? 1 : 2 : 3); 
 }