package lexer.tokens;

import lexer.Token;

public class Equal extends Token {
}
