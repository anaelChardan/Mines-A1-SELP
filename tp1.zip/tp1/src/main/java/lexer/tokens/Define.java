package lexer.tokens;

import lexer.Token;

public class Define extends Token {
}
