package lexer.tokens;

import lexer.Token;

public class RPar extends Token {
}
