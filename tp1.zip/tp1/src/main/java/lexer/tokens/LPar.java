package lexer.tokens;

import lexer.Token;

public class LPar extends Token {
}
