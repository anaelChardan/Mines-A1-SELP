package parser;

public class SyntacticError extends Exception {
    public SyntacticError(String s) {
        super(s);
    }
}
