#Anaël CHARDAN -> Compte rendu TP

##Avancée

### Analyse Lexicale
- Complètement terminée

### Analyse syntaxique
- Piste Verte : Complète
- Piste Bleu  : Complète
- Piste Rouge : Reste Program à analyser
- Piste Noire : Rien commencer

### Analyse sémantique
- Piste verte : complète et fonctionnel
- Piste bleu : complète
- Piste rouge : complète

##Gestion des erreurs

###Analyse Lexicale
- Des Exceptions de type : "Unexpected Character" sont lancées car ce sont des caractères non reconnu par notre grammaire

###Analyse Syntaxique
- Des Exceptions de type : "Syntactic Error" sont lancées car ce sont des mauvaises constructions de nos éléments qui sont détéctées

###Analyse Sémantique
- Des Exceptions de type : "Runtime Error" sont lancées car ce sont des choses non analysable